<?php

namespace Controllers;

class ErrorController {

    public function notFound(){

        echo 'not found';

    }

}