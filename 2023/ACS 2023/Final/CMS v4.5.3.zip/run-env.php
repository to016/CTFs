<?php

define ('WWWROOT', '/var/www/html');
define ('WWWDATA', WWWROOT . '/data');
define ('DB_CONF', WWWDATA . '/dbconfig.php');

function load_conf() : ?array {
    if (file_exists(DB_CONF)) {
        $file = explode("\n", file_get_contents(DB_CONF));
        $targets = [
            'G5_MYSQL_HOST',
            'G5_MYSQL_USER',
            'G5_MYSQL_PASSWORD',
            'G5_MYSQL_DB'
        ];

        $defs = [];
        foreach ($file as $i => $line) {
            $tmp = trim($line, " \t\r\n");

            if (($p = strpos($tmp, 'define')) !== false && !$p) {
                $cfg = explode(',', trim(substr($tmp, 6)), 2);
                $name = trim(substr($cfg[0], 1), " ;'\"\t");
                $val = trim(substr($cfg[1], 0, strlen($cfg[1]) - 2));

                if (array_search($name, $targets) !== false) {
                    eval("\$tmp = ${val};");
                    $defs[$name] = $tmp;
                }
            }
        }

        if (count(array_keys($defs)) != count($targets)) {
            return null;
        }
        
        return $defs;
    }
    
    return null;
}

function init() {
    if (!is_dir(WWWDATA)) {
        if (is_file(WWWDATA)) {
                shell_exec('rm -rf "' . WWWDATA .'"');
        }

        mkdir(WWWDATA, 0777);
        chown(WWWDATA, 'www-data');
        chgrp(WWWDATA, 'www-data');
    }

    if (!is_file(WWWDATA . "/.htaccess")) {
        $htaccess = [
            '<FilesMatch ".(cgi|pl|php|htm|html)$">',
            'Order allow,deny',
            'Deny from all',
            '</FilesMatch>',

            '<FilesMatch "^dbconfig.php$">',
            'Require all denied',
            '</FilesMatch>'
        ];

        file_put_contents(
            WWWDATA . "/.htaccess",
            implode("\n", $htaccess));

        chmod(WWWDATA . "/.htaccess", 0644);
    }

    
    if (!($defs = load_conf())) {
        return;
    }
    
    $ftime = filemtime(DB_CONF);
    while(true) {
        $conn = @mysqli_connect(
            $defs['G5_MYSQL_HOST'], 
            $defs['G5_MYSQL_USER'], $defs['G5_MYSQL_PASSWORD'], 
            $defs['G5_MYSQL_DB']);

        if ($conn) {
            mysqli_close($conn);
            break;
        }
        
        if (!file_exists(DB_CONF)) {
            break;
        }
        
        $ntime = filemtime(DB_CONF);
        if ($ntime != $ftime) {
            if (!($defs = load_conf())) {
                break;
            }
            
            $ftime = $ntime;
            continue;
        }

        usleep(100 * 1000);
    }
}

init();