<?php
if (!defined('_EYOOM_IS_ADMIN_')) exit;

/**
 * 추가메뉴 디렉토리
 */
//$cate_num = '100';
//$_dirname[$cate_num] = 'example';

/**
 * 추가메뉴 폰트어썸 아이콘
 */
//$dir_icon['example'] = 'fa-example';