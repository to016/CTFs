<?php
if (!defined('_EYOOM_IS_ADMIN_')) exit;

$menu['menu100'] = array (
    array('100000', '환경설정', G5_ADMIN_URL.'/eyoom_client/config_form.php',   'config'),
);

$menu['menu200'] = array (
    array('200000', '팝업설정', G5_ADMIN_URL.'/eyoom_client/config_form.php',   'config'),
);

$menu['menu300'] = array (
    array('300000', '회원관리', G5_ADMIN_URL.'/eyoom_client/config_form.php',   'config'),
);

$menu['menu400'] = array (
    array('400000', '게시판관리', G5_ADMIN_URL.'/eyoom_client/config_form.php',   'config'),
);

$menu['menu500'] = array (
    array('500000', '컨텐츠관리', G5_ADMIN_URL.'/eyoom_client/config_form.php',   'config'),
);