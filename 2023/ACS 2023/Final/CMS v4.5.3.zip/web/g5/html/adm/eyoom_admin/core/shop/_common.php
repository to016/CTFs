<?php
define('_EYOOM_IS_ADMIN_', true);
include_once('../../../../common.php');
