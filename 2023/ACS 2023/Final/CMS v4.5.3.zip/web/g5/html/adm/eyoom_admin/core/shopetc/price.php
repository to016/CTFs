<?php
/**
 * @file    /adm/eyoom_admin/core/shopetc/price.php
 */
if (!defined('_EYOOM_IS_ADMIN_')) exit;

$sub_menu = "500210";

auth_check_menu($auth, $sub_menu, "r");