<?php
/**
 * @file    /adm/eyoom_admin/core/shopetc/sale1.php
 */
if (!defined('_EYOOM_IS_ADMIN_')) exit;

$sub_menu = "500110";

auth_check_menu($auth, $sub_menu, "r");
