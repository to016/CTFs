<?php
$sub_menu = "100500";

header('location:../../../phpinfo.php');