<script type="text/javascript" src="/static/common.js?v=2"></script>
</body>
</html>