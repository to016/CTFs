use zigger;
create table flag (flag varchar(40));
insert into flag values ('ACS{fakeflag}');