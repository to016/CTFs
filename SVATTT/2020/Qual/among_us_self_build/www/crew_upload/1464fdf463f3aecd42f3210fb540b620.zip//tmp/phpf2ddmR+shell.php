<?php

	error_reporting( ~E_DEPRECATED & ~E_NOTICE );
	// but I strongly suggest you to use PDO or MySQLi.
	
	define('DBHOST', 'db');
	define('DBUSER', 'hackemall');
	define('DBPASS', 'h@ckemall');
	define('DBNAME', 'among_us');
	
	$conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
	$sql = "SELECT * FROM xxx_fl4g_xxx";
	
	$result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "id: " . $row ."<br>";
            foreach ($row as $item) {
                echo $item;
            }
             
        }
    }